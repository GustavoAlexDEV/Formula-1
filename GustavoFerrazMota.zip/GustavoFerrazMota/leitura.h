#ifndef LEITURA_H
#define LEITURA_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "registros.h"

void le_estrutura(FILE *arq,Estrutura_Pilotos *Pilotos,Estrutura_Equipes* Equipes,int n);

#endif