#ifndef ORDENACAO_H
#define ORDENACAO_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "registros.h"

void calcula_resultado(Estrutura_Pilotos *Pilotos,Estrutura_Equipes *Equipes,int n);

#endif