#ifndef PROCESSAMENTO_H
#define PROCESSAMENTO_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "registros.h"

void le_partidas(FILE *arq,Estrutura_Pilotos *Pilotos,Estrutura_Equipes *Equipes,int tabela[],int n,int m);

#endif