#ifndef ESCRITA_H
#define ESCRITA_H
#include "registros.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void escrever_resultados(FILE *arq,Estrutura_Pilotos *Pilotos, Estrutura_Equipes *Equipes,int n);

#endif